<?php
if (!defined('ABSPATH')) {
    exit;
}
// Settings template code here...