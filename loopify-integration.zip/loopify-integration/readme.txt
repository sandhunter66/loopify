=== Loopify Integration ===
Contributors: loopify
Tags: woocommerce, loyalty, rewards
Requires at least: 5.8
Tested up to: 6.4
// Readme content here...