<?php
/**
 * Plugin Name: Loopify Integration
 * Plugin URI: https://loopify.com
 * Description: Integrates your WooCommerce store with Loopify loyalty system
 * Version: 1.0.0
 * Author: Loopify
 * Author URI: https://loopify.com
 * License: GPL v2 or later
 * Text Domain: loopify-integration
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin code here...